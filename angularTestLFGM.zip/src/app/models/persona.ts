export class Persona {
    $key: string;
    tipoProfPac: string;
    tipoDocumento: string;
    documento: string;
    nombres: string;
    apellidos: string;
    fechaNacimiento: string;
    correo: string;
    telefono: string;
    tipoRefAcom: string;
    nombresRefAcom: string;
    apellidosRefAcom: string;
    parentescoRefAcom: string;
    telefonoRefAcom: string;
    correoRefAcom: string;
/*     nombre: string;
    category: string;
    location: string;
    price: number; */
}
